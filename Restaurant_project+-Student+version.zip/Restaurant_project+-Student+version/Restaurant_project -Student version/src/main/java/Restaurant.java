import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Restaurant {
    private String name;
    private String location;
    public LocalTime openingTime;
    public LocalTime closingTime;
    private List<Item> menu = new ArrayList<>();

    public Restaurant(String name, String location, LocalTime openingTime, LocalTime closingTime) {
        this.name = name;
        this.location = location;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
    }

    public boolean isRestaurantOpen() {
        LocalTime currentTime = getCurrentTime();
        return !currentTime.isBefore(openingTime) && !currentTime.isAfter(closingTime);
    }

    public LocalTime getCurrentTime() {
        return LocalTime.now();
    }

    public List<Item> getMenu() {
        return new ArrayList<>(menu);
    }

    private Optional<Item> findItemByName(String itemName) {
        return menu.stream()
                .filter(item -> item.getName().equalsIgnoreCase(itemName))
                .findFirst();
    }

    public void addToMenu(String name, int price) {
        menu.add(new Item(name, price));
    }

    public void removeFromMenu(String itemName) throws itemNotFoundException {
        Item item = findItemByName(itemName)
                .orElseThrow(() -> new itemNotFoundException(itemName));
        menu.remove(item);
    }

    public int calculateOrderTotal(List<String> selectedItems) {
        return selectedItems.stream()
                .map(this::findItemByName)
                .filter(Optional::isPresent)
                .mapToInt(item -> item.get().getPrice())
                .sum();
    }

    public void displayDetails() {
        System.out.println("Restaurant: " + name + "\n" +
                           "Location: " + location + "\n" +
                           "Opening time: " + openingTime + "\n" +
                           "Closing time: " + closingTime + "\n" +
                           "Menu: " + getMenu());
    }

    public String getName() {
        return name;
    }
}
