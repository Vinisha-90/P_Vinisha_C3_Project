import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.time.LocalTime;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

class RestaurantTest {
    private Restaurant restaurant;
    private final String RESTAURANT_NAME = "Amelie's cafe";
    private final String LOCATION = "Chennai";
    private final LocalTime OPENING_TIME = LocalTime.parse("10:30:00");
    private final LocalTime CLOSING_TIME = LocalTime.parse("22:00:00");

    @BeforeEach
    public void setUp() {
        restaurant = new Restaurant(RESTAURANT_NAME, LOCATION, OPENING_TIME, CLOSING_TIME);
        restaurant.addToMenu("Sweet corn soup", 119);
        restaurant.addToMenu("Vegetable lasagne", 269);
        restaurant.addToMenu("Sizzling brownie", 319);
    }

    // >>>>>>>>>>>>>>>>>>>>>>> ORDER TOTAL <<<<<<<<<<<<<<<<<<<<<<<<<<
    @Test
    public void calculateOrderTotal_should_return_correct_total_when_items_are_selected() {
        int total = restaurant.calculateOrderTotal(Arrays.asList("Sweet corn soup", "Vegetable lasagne"));
        assertEquals(388, total);
    }

    @Test
    public void calculateOrderTotal_should_return_zero_when_no_items_are_selected() {
        int total = restaurant.calculateOrderTotal(Collections.emptyList());
        assertEquals(0, total);
    }

    // >>>>>>>>>>>>>>>>>>>>>>> OPEN/CLOSED <<<<<<<<<<<<<<<<<<<<<<<<<<
    @Test
    public void is_restaurant_open_should_return_true_if_time_is_between_opening_and_closing_time() {
        Restaurant spyRestaurant = Mockito.spy(restaurant);
        when(spyRestaurant.getCurrentTime()).thenReturn(LocalTime.parse("12:00:00"));

        assertTrue(spyRestaurant.isRestaurantOpen());
    }

    @Test
    public void is_restaurant_open_should_return_false_if_time_is_outside_opening_and_closing_time() {
        Restaurant spyRestaurant = Mockito.spy(restaurant);
        when(spyRestaurant.getCurrentTime()).thenReturn(LocalTime.parse("23:30:00"));

        assertFalse(spyRestaurant.isRestaurantOpen());
    }

    // >>>>>>>>>>>>>>>>>>>>>>> MENU <<<<<<<<<<<<<<<<<<<<<<<<<<
    @Test
    public void adding_item_to_menu_should_increase_menu_size_by_1() {
        int initialMenuSize = restaurant.getMenu().size();
        restaurant.addToMenu("Pasta", 250);
        assertEquals(initialMenuSize + 1, restaurant.getMenu().size());
    }

    @Test
    public void removing_item_from_menu_should_decrease_menu_size_by_1() throws itemNotFoundException {
        int initialMenuSize = restaurant.getMenu().size();
        restaurant.removeFromMenu("Vegetable lasagne");
        assertEquals(initialMenuSize - 1, restaurant.getMenu().size());
    }

    @Test
    public void removing_item_that_does_not_exist_should_throw_exception() {
        assertThrows(itemNotFoundException.class,
                () -> restaurant.removeFromMenu("French fries"));
    }
}
